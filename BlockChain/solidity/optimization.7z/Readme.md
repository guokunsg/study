Play with Ethereum assembly for optimization 
(not sure about correctness or any security issue but can be deployed and run)
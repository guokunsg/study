var Web3 = require('web3');
var web3 = new Web3(new Web3.providers.HttpProvider("http://localhost:8545"));
var Personal = require('web3-eth-personal');

let abi = JSON.parse('[{"constant":false,"inputs":[{"name":"sig1","type":"bytes"},{"name":"sig2","type":"bytes"}],"name":"withdraw","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"}]');

function runContract(contract) {
    console.debug("newContract address", contract.options.address);
    contract.methods.withdraw(
        "0x9a5f6c3d90edf059441a50f2b8ad5035d054a618a32ff6cb76729ea840afa7743cd61aa667f0e7277d812f1d96a795ca86a881500d9c76a937630d5ca84c1cc41c", // Signature 1
        //"0xf7ae2b6fa2a0c5adad960321e620110952a87e67f855b6230c2dee36fae712467918b3c30f516bc78a5b018a00778393c1defb580ca9065b4c5752a030f82b0d1c" // Signature 2
        "0x00ae2b6fa2a0c5adad960321e620110952a87e67f855b6230c2dee36fae712467918b3c30f516bc78a5b018a00778393c1defb580ca9065b4c5752a030f82b0d1c" // Signature 2
    )
    .call((err, result) => {
        console.debug("Incorrect signature run result: Error=" + err + " result=", result);
    });

    contract.methods.withdraw(
        "0x9a5f6c3d90edf059441a50f2b8ad5035d054a618a32ff6cb76729ea840afa7743cd61aa667f0e7277d812f1d96a795ca86a881500d9c76a937630d5ca84c1cc41c", // Signature 1
        "0xf7ae2b6fa2a0c5adad960321e620110952a87e67f855b6230c2dee36fae712467918b3c30f516bc78a5b018a00778393c1defb580ca9065b4c5752a030f82b0d1c" // Signature 2
    ).call((err, result) => {
        console.debug("Correct signature result: error=" + err + " result=", result);
    });
}

web3.eth.getAccounts(function(error, accounts) {
    var account = accounts[0];
    
    console.log("Account: " + account);
    var binary = '0x' + '61009c80600D6000396000f3007f3E2D111C8C52A5EF0BA64FE4D85E32A5153032367EC44AAAE0A4E2D1BFB9BEBD60605260447320A95C0DDC1483AC6F87F18DCA5956DF254FAA0B6084606460A46067565b609973B4C88EF2B5D41D0E3014BDA4A6DF62C40A575B4061010460E46101246067565b3560001a6080523560A0523560C052602061010060806060600060015af11560925761010051146097575b600080FD5b565b33ff';
    var contract = new web3.eth.Contract(abi);
    //console.debug(contract);
    contract.deploy( { data: binary })
        .send({
            from: account, gas: 1500000, gasPrice: "30"
        }, function(error, transHash) {
            console.debug("Contract deploy result. Error:", error, "TransactionHash:", transHash);
        })
        .on('error', error => { console.debug("Error", error); })
        .on('transactionHash', hash => { console.debug("Transaction hash", hash); })
        .on('receipt', receipt => { console.debug("Receipt: ")})
        .then((newContract) => { runContract(newContract); } );
});


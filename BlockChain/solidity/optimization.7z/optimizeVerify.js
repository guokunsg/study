/** 2 signature verification implementation:
pragma solidity ^0.4.16;
contract Verify {
    // Remix test string: "0x3e2d111c8c52a5ef0ba64fe4d85e32a5153032367ec44aaae0a4e2d1bfb9bebd", "0x20a95c0ddc1483ac6f87f18dca5956df254faa0b", "0xb4c88ef2b5d41d0e3014bda4a6df62c40a575b40", ["0x9a","0x5f","0x6c","0x3d","0x90","0xed","0xf0","0x59","0x44","0x1a","0x50","0xf2","0xb8","0xad","0x50","0x35","0xd0","0x54","0xa6","0x18","0xa3","0x2f","0xf6","0xcb","0x76","0x72","0x9e","0xa8","0x40","0xaf","0xa7","0x74","0x3c","0xd6","0x1a","0xa6","0x67","0xf0","0xe7","0x27","0x7d","0x81","0x2f","0x1d","0x96","0xa7","0x95","0xca","0x86","0xa8","0x81","0x50","0x0d","0x9c","0x76","0xa9","0x37","0x63","0x0d","0x5c","0xa8","0x4c","0x1c","0xc4","0x1c"], ["0xf7","0xae","0x2b","0x6f","0xa2","0xa0","0xc5","0xad","0xad","0x96","0x03","0x21","0xe6","0x20","0x11","0x09","0x52","0xa8","0x7e","0x67","0xf8","0x55","0xb6","0x23","0x0c","0x2d","0xee","0x36","0xfa","0xe7","0x12","0x46","0x79","0x18","0xb3","0xc3","0x0f","0x51","0x6b","0xc7","0x8a","0x5b","0x01","0x8a","0x00","0x77","0x83","0x93","0xc1","0xde","0xfb","0x58","0x0c","0xa9","0x06","0x5b","0x4c","0x57","0x52","0xa0","0x30","0xf8","0x2b","0x0d","0x1c"]
    function verify(bytes32 hash, address addr1, address add2, bytes sig1, bytes sig2) external {
        assembly {
            mstore(0x60, calldataload(4)) // Hash. Starting address
            let r := f(0x104, 0xc4, 0xe4, 0x24)
            r := f(0x184, 0x144, 0x164, 0x44)
            function f(V, R, S, A) -> y {
                mstore(0x80, byte(0, calldataload(V))) // V
                mstore(0xA0, calldataload(R)) // R
                mstore(0xC0, calldataload(S)) // S
                mstore(0xE0, calldataload(A)) // A
                jumpi(err, iszero(call(gas, 0x1, 0, 0x60, 0x80, 0x100, 0x20)))
                jumpi(pass, eq(mload(0x100), mload(0xE0)))
                err:
                    revert(0, 0)
                pass:
            }
        }
    }
}
To get bin: solc --bin Verify.sol
To get opcode: solc --opcodes Verify.sol
*/

const ORG_BIN = "6060604052341561000f57600080fd5b6101478061001e6000396000f3006060604052600436106100405763ffffffff7c0100000000000000000000000000000000000000000000000000000000600035041663a1a7e0d38114610045575b600080fd5b341561005057600080fd5b610095600480359073ffffffffffffffffffffffffffffffffffffffff6024803582169260443590921691606435808301929082013591608435918201910135610097565b005b6004356060526100ae602460e460c46101046100c8565b6100c160446101646101446101846100c8565b9050610111565b6000813560001a608052823560a052833560c052843560e0526001602061010060806060600060015af114156100405760e051610100511461010957600080fd5b949350505050565b50505050505050505600a165627a7a72305820c7bcc318d27193e389b72426f3060f215b301a402d71b66ca235abfb64d11f810029";

const ORG_OPCODES = 
    "PUSH1 0x60 PUSH1 0x40 MSTORE CALLVALUE ISZERO PUSH2 0xF JUMPI PUSH1 0x0 DUP1 REVERT JUMPDEST PUSH2 0x147 DUP1 PUSH2 0x1E PUSH1 0x0 CODECOPY PUSH1 0x0 RETURN STOP PUSH1 0x60 PUSH1 0x40 MSTORE PUSH1 0x4 CALLDATASIZE LT PUSH2 0x40 JUMPI PUSH4 0xFFFFFFFF PUSH29 0x100000000000000000000000000000000000000000000000000000000 PUSH1 0x0 CALLDATALOAD DIV AND PUSH4 0xA1A7E0D3 DUP2 EQ PUSH2 0x45 JUMPI JUMPDEST PUSH1 0x0 DUP1 REVERT JUMPDEST CALLVALUE ISZERO PUSH2 0x50 JUMPI PUSH1 0x0 DUP1 REVERT JUMPDEST PUSH2 0x95 PUSH1 0x4 DUP1 CALLDATALOAD SWAP1 PUSH20 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF PUSH1 0x24 DUP1 CALLDATALOAD DUP3 AND SWAP3 PUSH1 0x44 CALLDATALOAD SWAP1 SWAP3 AND SWAP2 PUSH1 0x64 CALLDATALOAD DUP1 DUP4 ADD SWAP3 SWAP1 DUP3 ADD CALLDATALOAD SWAP2 PUSH1 0x84 CALLDATALOAD SWAP2 DUP3 ADD SWAP2 ADD CALLDATALOAD PUSH2 0x97 JUMP JUMPDEST STOP JUMPDEST PUSH1 0x4 CALLDATALOAD PUSH1 0x60 MSTORE PUSH2 0xAE PUSH1 0x24 PUSH1 0xE4 PUSH1 0xC4 PUSH2 0x104 PUSH2 0xC8 JUMP JUMPDEST PUSH2 0xC1 PUSH1 0x44 PUSH2 0x164 PUSH2 0x144 PUSH2 0x184 PUSH2 0xC8 JUMP JUMPDEST SWAP1 POP PUSH2 0x111 JUMP JUMPDEST PUSH1 0x0 DUP2 CALLDATALOAD PUSH1 0x0 BYTE PUSH1 0x80 MSTORE DUP3 CALLDATALOAD PUSH1 0xA0 MSTORE DUP4 CALLDATALOAD PUSH1 0xC0 MSTORE DUP5 CALLDATALOAD PUSH1 0xE0 MSTORE PUSH1 0x1 PUSH1 0x20 PUSH2 0x100 PUSH1 0x80 PUSH1 0x60 PUSH1 0x0 PUSH1 0x1 GAS CALL EQ ISZERO PUSH2 0x40 JUMPI PUSH1 0xE0 MLOAD PUSH2 0x100 MLOAD EQ PUSH2 0x109 JUMPI PUSH1 0x0 DUP1 REVERT JUMPDEST SWAP5 SWAP4 POP POP POP POP JUMP JUMPDEST POP POP POP POP POP POP POP POP JUMP STOP LOG1 PUSH6 0x627A7A723058 KECCAK256 0xc7 0xbc 0xc3 XOR 0xd2 PUSH18 0x93E389B72426F3060F215B301A402D71B66C LOG2 CALLDATALOAD 0xab CREATE2 PUSH5 0xD11F810029";

const HEADER_LEN = 0x11;
function genContractHeader(body) {
    let bodySize = ("0000" + (body.length / 2).toString(16)).slice(-4); // Compute the body size
    console.debug("Body size", bodySize);
    return "PUSH2 0x" + bodySize + " DUP1 PUSH1 0x0D PUSH1 0x00 CODECOPY PUSH1 0x0 RETURN STOP ";
}

function genBody() {
    let code = 
    "PUSH1 0x4 CALLDATALOAD PUSH1 0x60 MSTORE " + // Get hash. Use 0x60 as start address for calling ecrecover
    "PUSH1 0x14 " + // Address to jump to after the function call
    "PUSH1 0x24 PUSH1 0xE4 PUSH1 0xC4 PUSH2 0x104 PUSH1 0x25 JUMP " + // Call function parameters: A, S, R, V
    
    "JUMPDEST " + // Second call to the function
    "PUSH1 0x5E " + // Address to jump to after the function call
    "PUSH1 0x44 PUSH2 0x164 PUSH2 0x144 PUSH2 0x184 PUSH1 0x25 JUMP " + // Call function parameters: A, S, R, V
    
    "JUMPDEST " + // Function
    "CALLDATALOAD PUSH1 0x0 BYTE PUSH1 0x80 MSTORE " + // Get V
    "CALLDATALOAD PUSH1 0xA0 MSTORE " + // Get R
    "CALLDATALOAD PUSH1 0xC0 MSTORE " + // Get S
    "CALLDATALOAD PUSH1 0xE0 MSTORE " + // Get A
    "PUSH1 0x20 PUSH2 0x100 PUSH1 0x80 PUSH1 0x60 PUSH1 0x0 PUSH1 0x1 GAS CALL " + // Call ecrecover
    "ISZERO PUSH1 0x57 JUMPI " + // If call recover returns error, goto revert
    "PUSH1 0xE0 MLOAD PUSH2 0x100 MLOAD EQ PUSH1 0x5C JUMPI " + // Compare the recovered address
    "JUMPDEST PUSH1 0x0 DUP1 REVERT " + // Revert
    "JUMPDEST JUMP " + // Jump to the location which is still left in the stack
    "JUMPDEST STOP" + // Final destination
    "";
    return code;
}

require("./opcodeTranslator")()
.then(trans => {
    // Verify the original code to be sure the same as the bin
    let genCode = trans.translate(ORG_OPCODES);
    trans.compareDifference(ORG_BIN.toUpperCase(), genCode.toUpperCase());
    return trans; 
})
.then(trans => {
    let bodyCode = genBody();
    console.debug("Bodycode:", bodyCode);
    let bodyBin = trans.translate(bodyCode);
    let headerCode = genContractHeader(bodyBin);
    let headerBin = trans.translate(headerCode);
    console.debug("opcode:", headerCode + bodyCode);
    let genCode = headerBin + bodyBin;
    console.debug(genCode);
})
;



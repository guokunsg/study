/** 2 signature verification implementation:
pragma solidity ^0.4.16;
contract MultiSig {   
    // Remix test string: ["0x9a","0x5f","0x6c","0x3d","0x90","0xed","0xf0","0x59","0x44","0x1a","0x50","0xf2","0xb8","0xad","0x50","0x35","0xd0","0x54","0xa6","0x18","0xa3","0x2f","0xf6","0xcb","0x76","0x72","0x9e","0xa8","0x40","0xaf","0xa7","0x74","0x3c","0xd6","0x1a","0xa6","0x67","0xf0","0xe7","0x27","0x7d","0x81","0x2f","0x1d","0x96","0xa7","0x95","0xca","0x86","0xa8","0x81","0x50","0x0d","0x9c","0x76","0xa9","0x37","0x63","0x0d","0x5c","0xa8","0x4c","0x1c","0xc4","0x1c"], ["0xf7","0xae","0x2b","0x6f","0xa2","0xa0","0xc5","0xad","0xad","0x96","0x03","0x21","0xe6","0x20","0x11","0x09","0x52","0xa8","0x7e","0x67","0xf8","0x55","0xb6","0x23","0x0c","0x2d","0xee","0x36","0xfa","0xe7","0x12","0x46","0x79","0x18","0xb3","0xc3","0x0f","0x51","0x6b","0xc7","0x8a","0x5b","0x01","0x8a","0x00","0x77","0x83","0x93","0xc1","0xde","0xfb","0x58","0x0c","0xa9","0x06","0x5b","0x4c","0x57","0x52","0xa0","0x30","0xf8","0x2b","0x0d","0x1c"]
    function withdraw(bytes sig1, bytes sig2) external {
        assembly {
            mstore(0x60, 0x3e2d111c8c52a5ef0ba64fe4d85e32a5153032367ec44aaae0a4e2d1bfb9bebd)
            let r := f(0xA4, 0x64, 0x84, 0x20a95c0ddc1483ac6f87f18dca5956df254faa0b)
            r := f(0x124, 0xE4, 0x104, 0xb4c88ef2b5d41d0e3014bda4a6df62c40a575b40)
            selfdestruct(caller)

            function f(V, R, S, A) -> y {
                mstore(0x80, byte(0, calldataload(V))) // V
                mstore(0xA0, calldataload(R)) // R
                mstore(0xC0, calldataload(S)) // S
                if eq(call(gas, 0x1, 0, 0x60, 0x80, 0x100, 0x20), 1) {
                    jumpi(pass, eq(mload(0x100), A))
                }
                revert(0, 0)
                pass:
            }
        }
    }
}
To get bin: solc --bin MultiSig.sol
To get opcode: solc --opcodes MultiSig.sol
*/

const ORG_BIN = "6060604052341561000f57600080fd5b6101508061001e6000396000f3006060604052600436106100405763ffffffff7c010000000000000000000000000000000000000000000000000000000060003504166350fbe2d98114610045575b600080fd5b341561005057600080fd5b61006f6024600480358281019290820135918135918201910135610071565b005b7f3e2d111c8c52a5ef0ba64fe4d85e32a5153032367ec44aaae0a4e2d1bfb9bebd6060526100b87320a95c0ddc1483ac6f87f18dca5956df254faa0b6084606460a46100e2565b6100dd73b4c88ef2b5d41d0e3014bda4a6df62c40a575b4061010460e46101246100e2565b905033ff5b6000813560001a608052823560a052833560c0526001602061010060806060600060015af114156100405784610100511461011c57600080fd5b9493505050505600a165627a7a72305820c2df047dcbd02e0bd0b9b7f8f580687a49dd920b7f3be803d472536e12291dbb0029";

const ORG_OPCODES = 
    "PUSH1 0x60 PUSH1 0x40 MSTORE CALLVALUE ISZERO PUSH2 0xF JUMPI PUSH1 0x0 DUP1 REVERT JUMPDEST PUSH2 0x150 DUP1 PUSH2 0x1E PUSH1 0x0 CODECOPY PUSH1 0x0 RETURN STOP PUSH1 0x60 PUSH1 0x40 MSTORE PUSH1 0x4 CALLDATASIZE LT PUSH2 0x40 JUMPI PUSH4 0xFFFFFFFF PUSH29 0x100000000000000000000000000000000000000000000000000000000 PUSH1 0x0 CALLDATALOAD DIV AND PUSH4 0x50FBE2D9 DUP2 EQ PUSH2 0x45 JUMPI JUMPDEST PUSH1 0x0 DUP1 REVERT JUMPDEST CALLVALUE ISZERO PUSH2 0x50 JUMPI PUSH1 0x0 DUP1 REVERT JUMPDEST PUSH2 0x6F PUSH1 0x24 PUSH1 0x4 DUP1 CALLDATALOAD DUP3 DUP2 ADD SWAP3 SWAP1 DUP3 ADD CALLDATALOAD SWAP2 DUP2 CALLDATALOAD SWAP2 DUP3 ADD SWAP2 ADD CALLDATALOAD PUSH2 0x71 JUMP JUMPDEST STOP JUMPDEST PUSH32 0x3E2D111C8C52A5EF0BA64FE4D85E32A5153032367EC44AAAE0A4E2D1BFB9BEBD PUSH1 0x60 MSTORE PUSH2 0xB8 PUSH20 0x20A95C0DDC1483AC6F87F18DCA5956DF254FAA0B PUSH1 0x84 PUSH1 0x64 PUSH1 0xA4 PUSH2 0xE2 JUMP JUMPDEST PUSH2 0xDD PUSH20 0xB4C88EF2B5D41D0E3014BDA4A6DF62C40A575B40 PUSH2 0x104 PUSH1 0xE4 PUSH2 0x124 PUSH2 0xE2 JUMP JUMPDEST SWAP1 POP CALLER SELFDESTRUCT JUMPDEST PUSH1 0x0 DUP2 CALLDATALOAD PUSH1 0x0 BYTE PUSH1 0x80 MSTORE DUP3 CALLDATALOAD PUSH1 0xA0 MSTORE DUP4 CALLDATALOAD PUSH1 0xC0 MSTORE PUSH1 0x1 PUSH1 0x20 PUSH2 0x100 PUSH1 0x80 PUSH1 0x60 PUSH1 0x0 PUSH1 0x1 GAS CALL EQ ISZERO PUSH2 0x40 JUMPI DUP5 PUSH2 0x100 MLOAD EQ PUSH2 0x11C JUMPI PUSH1 0x0 DUP1 REVERT JUMPDEST SWAP5 SWAP4 POP POP POP POP JUMP STOP LOG1 PUSH6 0x627A7A723058 KECCAK256 0xc2 0xdf DIV PUSH30 0xCBD02E0BD0B9B7F8F580687A49DD920B7F3BE803D472536E12291DBB0029 ";

const HEADER_LEN = 0x11;
function genContractHeader(body) {
    let bodySize = ("0000" + (body.length / 2).toString(16)).slice(-4); // Compute the body size
    console.debug("Body size", bodySize);
    return "PUSH2 0x" + bodySize + " DUP1 PUSH1 0x0D PUSH1 0x00 CODECOPY PUSH1 0x0 RETURN STOP ";
}

function genBody() {
    let code = 
    "PUSH32 0x3E2D111C8C52A5EF0BA64FE4D85E32A5153032367EC44AAAE0A4E2D1BFB9BEBD PUSH1 0x60 MSTORE " + // Use 0x60 as start address for calling ecrecover. Store the hash value
    "PUSH1 0x44 " + // The code to jump back after the function call
    "PUSH20 0x20A95C0DDC1483AC6F87F18DCA5956DF254FAA0B PUSH1 0x84 PUSH1 0x64 PUSH1 0xA4 PUSH1 0x67 JUMP " + // Call function with parameters: Expected address, S, R, V

    "JUMPDEST " + // The second function call block
    "PUSH1 0x99 " + // Jump to the final destination
    "PUSH20 0xB4C88EF2B5D41D0E3014BDA4A6DF62C40A575B40 PUSH2 0x104 PUSH1 0xE4 PUSH2 0x124 PUSH1 0x67 JUMP " + // Call function with parameters: Expected address, S, R, V
    
    "JUMPDEST " + // Function
        "CALLDATALOAD PUSH1 0x0 BYTE PUSH1 0x80 MSTORE " + // Store V
        "CALLDATALOAD PUSH1 0xA0 MSTORE " + // Store R
        "CALLDATALOAD PUSH1 0xC0 MSTORE " + // Store S
        "PUSH1 0x20 PUSH2 0x100 PUSH1 0x80 PUSH1 0x60 PUSH1 0x0 PUSH1 0x1 GAS CALL " + // Call ecrecover
        "ISZERO PUSH1 0x92 JUMPI " + // If function call return 0, jump to revert
        "PUSH2 0x100 MLOAD EQ PUSH1 0x97 JUMPI " + // Load the recovered address and compare with the expected address. If successful, jump to the code left in the stack
            "JUMPDEST PUSH1 0x0 DUP1 REVERT " + // Revert destination
            "JUMPDEST JUMP " + 
        
    "JUMPDEST CALLER SELFDESTRUCT " + // Final destination on successful reverification. Self destruct
    "";

    return code;
}

require("./opcodeTranslator")()
.then(trans => {
    // Verify the original code to be sure the same as the bin
    let genCode = trans.translate(ORG_OPCODES);
    trans.compareDifference(ORG_BIN.toUpperCase(), genCode.toUpperCase());
    return trans; 
})
.then(trans => {
    let bodyCode = genBody();
    console.debug("Bodycode:", bodyCode);
    let bodyBin = trans.translate(bodyCode);
    let headerCode = genContractHeader(bodyBin);
    let headerBin = trans.translate(headerCode);
    console.debug("opcode:", headerCode + bodyCode);
    let genCode = headerBin + bodyBin;
    console.debug(genCode);
})
;



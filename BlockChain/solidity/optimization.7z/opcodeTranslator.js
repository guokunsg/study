class Translator {
    constructor(map) {
        this.map = map;
    }

    translate(opcode)  {
        opcode = opcode.replace(/\n/g, "");
        let tokens = opcode.split(' ');
        let s = "";
        let prev = "";
        for (let t of tokens) {
            if (t.length === 0)
                continue;
            if (t.startsWith('0x')) {
                t = t.replace("0x", "");
                if (t.length % 2 != 0)
                    t = "0" + t;
                if (prev === 'PUSH2')
                    if (t.length < 4)
                        t = ("00" + t).slice(-4);
                s += t;
            } else {
                if (t === 'JUMPDEST')
                    console.debug("JUMPDEST: " + (s.length / 2).toString(16));
                let v = this.map.get(t);
                if (v === undefined || v === null)
                    throw ("No value found for " + t);
                s += v;
            }
            prev = t;
        }
        return s;
    }

    compareDifference(A, B) {
        let len = Math.min(A.length, B.length);
        for (let i = 0; i < len; i ++) {
            if (A[i] !== B[i]) {
                console.debug("DIFF BIN AT: " + A.substring(0, i + 1));
                console.debug("CODE GEN AT: " + B.substring(0, i + 1));
                throw "Different!";
            }
        }
    }
}

module.exports = function() {
    return new Promise((resolve, reject) => {
        // Load OPCODE to HEX value mapping from opcodes.csv file
        let map = new Map();
        const lineReader = require('readline').createInterface({
            input: require('fs').createReadStream('opcodes.csv')
        });
        lineReader.on('line', line => {
            if (line.startsWith("0x")) {
                let pair = line.split(',', 2);
                let value = pair[0].replace(/0x/, "");
                let opcode = pair[1];
                // Ignore ranged push, dup, swap
                if (value.indexOf('--') === -1) {
                    map.set(opcode, value);
                }
            }
        })
        .on('close', () => {
            // Add in special ones
            for (let i = 0; i < 32; i ++) 
                map.set("PUSH" + (i + 1), (0x60 + i).toString(16));
            for (let i = 0; i < 16; i ++) {
                map.set("DUP" + (i + 1), (0x80 + i).toString(16));
                map.set("SWAP" + (i + 1), (0x90 + i).toString(16));
            }
            map.set('KECCAK256', '20');
            map.set('REVERT', 'FD');
            map.set('RETURNDATASIZE', '3D');
            map.set('RETURNDATACOPY', '3E');
            map.set('CREATE2', 'fb');
            
            resolve(new Translator(map));
        });
    });
}

var Web3 = require('web3');
var web3 = new Web3(new Web3.providers.HttpProvider("http://localhost:8545"));

let abi = JSON.parse('[{"constant":false,"inputs":[{"name":"preimage","type":"bytes32"}],"name":"pay","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"}]');

function runContract(contract) {
    console.debug("newContract address", contract.options.address);
    contract.methods.pay('0x000000000019d6689c085ae165831e934ff763ae46a2a6c172b3f1b60a8ce26f').call();
    //contract.methods.pay('0x110000000019d6689c085ae165831e934ff763ae46a2a6c172b3f1b60a8ce26f').call();
}

web3.eth.getAccounts(function(error, accounts) {
    var account = accounts[0];
    console.log("Account: " + account);
    var binary = '0x' + '61006d80600D6000396000f30060043560605260206060207fFE07BFCF888C2AAD5F4586A3371AE0B7A23D7829C6142817829ED5F28D381DA41415604757737D551397F79A2988B064AFD0EFEBEE802C7721BCff5b635AD9E88F4211605657600080FD5b73DE0B295669A9FD93D5F28D9EC85E40F4CB697BAEff';
    var contract = new web3.eth.Contract(abi);
    console.debug(contract);
    contract.deploy( { data: binary })
        .send({
            from: account, gas: 1500000, gasPrice: "30"
        }, function(error, transHash) {
            console.debug("Error", error, "TransactionHash", transHash);
        })
        .on('error', error => { console.debug("Error", error); })
        .on('transactionHash', hash => { console.debug("Transaction hash", hash); })
        .on('receipt', receipt => { console.debug("Receipt")})
        .then((newContract) => { runContract(newContract); } );
});


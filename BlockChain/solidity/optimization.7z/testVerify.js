var Web3 = require('web3');
var web3 = new Web3(new Web3.providers.HttpProvider("http://localhost:8545"));
var Personal = require('web3-eth-personal');

let abi = JSON.parse('[{"constant":false,"inputs":[{"name":"hash","type":"bytes32"},{"name":"addr1","type":"address"},{"name":"add2","type":"address"},{"name":"sig1","type":"bytes"},{"name":"sig2","type":"bytes"}],"name":"verify","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"}]');

function runContract(contract) {
    console.debug("newContract address", contract.options.address);
    contract.methods.verify(
        "0x3e2d111c8c52a5ef0ba64fe4d85e32a5153032367ec44aaae0a4e2d1bfb9bebd", // Message hash
        "0x20a95c0ddc1483ac6f87f18dca5956df254faa0b", // Address 1
        "0xb4c88ef2b5d41d0e3014bda4a6df62c40a575b40", // Address 2
        "0x9a5f6c3d90edf059441a50f2b8ad5035d054a618a32ff6cb76729ea840afa7743cd61aa667f0e7277d812f1d96a795ca86a881500d9c76a937630d5ca84c1cc41c", // Signature 1
        //"0xf7ae2b6fa2a0c5adad960321e620110952a87e67f855b6230c2dee36fae712467918b3c30f516bc78a5b018a00778393c1defb580ca9065b4c5752a030f82b0d1c" // Signature 2
        "0xf8ae2b6fa2a0c5adad960321e620110952a87e67f855b6230c2dee36fae712467918b3c30f516bc78a5b018a00778393c1defb580ca9065b4c5752a030f82b0d1c" // Signature 2
    ).call((err, result) => {
        console.debug("Incorrect signature run result: Error=" + err + " result=", result);
    });
    

    contract.methods.verify(
        "0x3e2d111c8c52a5ef0ba64fe4d85e32a5153032367ec44aaae0a4e2d1bfb9bebd", // Message hash
        "0x20a95c0ddc1483ac6f87f18dca5956df254faa0b", // Address 1
        "0xb4c88ef2b5d41d0e3014bda4a6df62c40a575b40", // Address 2
        "0x9a5f6c3d90edf059441a50f2b8ad5035d054a618a32ff6cb76729ea840afa7743cd61aa667f0e7277d812f1d96a795ca86a881500d9c76a937630d5ca84c1cc41c", // Signature 1
        "0xf7ae2b6fa2a0c5adad960321e620110952a87e67f855b6230c2dee36fae712467918b3c30f516bc78a5b018a00778393c1defb580ca9065b4c5752a030f82b0d1c" // Signature 2
    ).call((err, result) => {
        console.debug("Correct signature result: error=" + err + " result=", result);
    });
}

web3.eth.getAccounts(function(error, accounts) {
    var account = accounts[0];
    
    console.log("Account: " + account);
    var binary = '0x' + '61006080600D6000396000f3006004356060526014602460E460C46101046025565b605E60446101646101446101846025565b3560001a6080523560A0523560C0523560E052602061010060806060600060015af11560575760E0516101005114605C575b600080FD5b565b00';
    var contract = new web3.eth.Contract(abi);
    //console.debug(contract);
    contract.deploy( { data: binary })
        .send({
            from: account, gas: 1500000, gasPrice: "30"
        }, function(error, transHash) {
            console.debug("Contract deploy result. Error:", error, "TransactionHash:", transHash);
        })
        .on('error', error => { console.debug("Error", error); })
        .on('transactionHash', hash => { console.debug("Transaction hash", hash); })
        .on('receipt', receipt => { console.debug("Receipt: ")})
        .then((newContract) => { runContract(newContract); } );
});


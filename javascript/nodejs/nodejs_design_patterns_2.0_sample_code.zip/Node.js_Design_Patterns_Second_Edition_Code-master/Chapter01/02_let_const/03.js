"use strict";

const x = 'This will never change';
//x = '...'; // TypeError: Assignment to constant variable.

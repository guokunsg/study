This example shows a simple file compressor built using buffers.
To run it you can use:
  node index <path>

You can for example compress this readme file with:
  node index README.txt

This example implements a transform stream that also uses pipes. To run the example you just need to run:

  echo 'Hello World!' | node replace 'World' 'Node.js'

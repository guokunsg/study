This code shows an example about how to implement a stream that outputs whatever is sent through the
standard input using the flowing mode.

You can run the example with:

  cat README.txt | node readStdin

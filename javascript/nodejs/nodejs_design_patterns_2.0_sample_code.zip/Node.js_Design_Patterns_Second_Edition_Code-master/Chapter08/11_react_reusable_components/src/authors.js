"use strict";

module.exports = {

  'joyce': {
    'name': 'James Joyce',
    'books': [
      'Dubliners',
      'A Portrait of the Artist as a Young Man',
      'Exiles and poetry',
      'Ulysses',
      'Finnegans Wake'
    ]
  },

  'h-g-wells': {
    'name': 'Herbert George Wells',
    'books': [
      'The Time Machine',
      'The War of the Worlds',
      'The First Men in the Moon',
      'The Invisible Man'
    ]
  }
};

"use strict";

const toastr = require('toastr');
module.exports = toastr.info;

This example shows how to implement build time dynamic variables with webpack.

Before running the examples you need to install the dependencies with:

  npm install

Then you need to generate the bundle file for the browser with:

  node_modules/.bin/webpack

Finally you can run the resulting script in node with:

  node dist/bundle.js

This example shows a function to "promisify" callback based functions.

To run it launch:

  node test

This sample demonstrates how to create an Api that can be used both with a callback based approach or with promises.

The index.js file exports a function implemented in such way to offer both callback and promise support.
The test.js file uses this function in both ways.
  
Then execute the example run:
  node test

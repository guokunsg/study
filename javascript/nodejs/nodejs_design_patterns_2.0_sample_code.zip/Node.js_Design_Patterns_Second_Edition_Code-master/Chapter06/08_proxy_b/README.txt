This example illustrates how to create a proxy using plain objects.

To run the example simply execute:

  node test

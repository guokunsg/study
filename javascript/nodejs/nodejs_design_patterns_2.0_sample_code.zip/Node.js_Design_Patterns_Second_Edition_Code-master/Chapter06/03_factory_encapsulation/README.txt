This example shows how to implement a factory function that encapsulates private
properties or methods and exposes only a set of public properties and methods.

To run the example launch:

  node createPerson

"use strict";

module.exports = class Image {
  constructor(path) {
    this.path = path;
  }
};

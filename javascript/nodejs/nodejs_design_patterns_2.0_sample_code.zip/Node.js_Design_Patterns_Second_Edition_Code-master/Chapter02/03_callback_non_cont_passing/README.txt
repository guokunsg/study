This example shows non continuous passing with callbacks.

To run the example launch:

  node test

This example shows the revealing module pattern.

To run the example launch:

  node test

This sample demonstrates how the node-glob package, combines callbacks and 
and EventEmitter.
To run the sample code first install the dependencies:

  npm install

Then run the main program:

  node main

This example shows continuous passing with callbacks.

To run the example launch:

  node test
